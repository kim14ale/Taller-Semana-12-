int leerEntero(char* mensaje);
int leerEnteroPositivo(char* mensaje);
int leerEnteroEntre(char* mensaje, int a, int b);
float leerFlotantePositivo(char* mensaje);
float leerFlotanteEntre(char* mensaje, float a, float b);
char leerCaracter(const char* mensaje);
